#!/usr/bin/env python3
"""
HERMES MASTER — Clean Rewrite
══════════════════════════════════════════════════
- Connects to MT5 Bridge OR uses Yahoo Finance
- Runs analysis (SMC + Classic + DEFCON)
- Sends report via Telegram
- Executes trading commands (manual approval)
- DRY_RUN = True (safe mode)

Usage:
  cd /home/ai/hermes-trading && python3 hermes_master.py
"""
import os, sys, json, time
from datetime import datetime, timezone

sys.path.insert(0, "/home/ai/hermes-trading")
from hermes_brain import HermesMT5Bridge, fetch_yf_ohlc
from scripts.hermes_notifier import send_telegram
import hermes_analyzer

# ─── CONFIG ─────────────────────────────────────────
DRY_RUN       = True
CMD_FILE      = "/home/ai/hermes-trading/data/trading/hermes_command.txt"
REPORT_FILE   = "/home/ai/hermes-trading/logs/report.txt"
LOG_FILE      = "/home/ai/hermes-trading/logs/master.log"

# ─── LOGGING ────────────────────────────────────────
def log(msg):
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")

# ─── COMMANDS ───────────────────────────────────────
def read_command():
    if os.path.exists(CMD_FILE):
        with open(CMD_FILE, "r") as f:
            cmd = f.read().strip()
        os.remove(CMD_FILE)
        return cmd
    return None

def write_command(cmd):
    os.makedirs(os.path.dirname(CMD_FILE), exist_ok=True)
    with open(CMD_FILE, "w") as f:
        f.write(cmd)

def execute_trade(bridge, cmd, account, positions):
    parts = cmd.split()
    action = parts[0]
    
    if action == "/trade":
        direction = parts[1] if len(parts) > 1 else "buy"
        lot = float(parts[2]) if len(parts) > 2 else 0.01
        sl = float(parts[3]) if len(parts) > 3 else None
        tp = float(parts[4]) if len(parts) > 4 else None
        return bridge.send_order(direction, lot, "XAUUSD", sl, tp) if bridge.connected else {"ok": False, "error": "bridge_offline"}
    
    elif action == "/close":
        ticket = int(parts[1]) if len(parts) > 1 else 0
        if ticket == 0 and positions:
            ticket = positions[0]["ticket"]
        return bridge.close_position(ticket) if bridge.connected else {"ok": False, "error": "bridge_offline"}
    
    return {"ok": False, "error": "unknown_command"}

# ─── MAIN ───────────────────────────────────────────
def main():
    log("=" * 45)
    log("HERMES MASTER — Cycle Start")
    log(f"DRY_RUN={DRY_RUN}")
    
    bridge = HermesMT5Bridge()
    bridge_ok = bridge.connect()
    log(f"Bridge: {'OK' if bridge_ok else 'OFFLINE'}")
    
    # Data sources
    tick = bridge.get_tick("XAUUSD") if bridge_ok else {"ok": False}
    account = bridge.get_account() if bridge_ok else {"ok": False}
    positions = bridge.get_positions("XAUUSD") if bridge_ok else {"ok": False, "data": []}
    
    balance = account.get("balance", 0) if account.get("ok") else 0
    equity  = account.get("equity", 0) if account.get("ok") else 0
    bid     = tick.get("bid", 0) if tick.get("ok") else 0
    ask     = tick.get("ask", 0) if tick.get("ok") else 0
    pos_list = positions.get("data", []) if positions.get("ok") else []
    
    # ANALYSIS — try MT5 first, then Yahoo
    analysis = None
    data_source = ""
    current_price = bid if bid else ask
    
    # Try Bridge OHLC
    if bridge_ok:
        ohlc_m15 = bridge.get_ohlc("XAUUSD", "M15", 50)
        if ohlc_m15.get("ok"):
            analysis = hermes_analyzer.analyze(ohlc_m15.get("data", []), [], current_price)
            data_source = "MT5"
            log(f"Analysis (MT5): {analysis['bias']} conf={analysis['confidence']}% DEFCON={analysis['defcon']['level']}")
    
    # Fallback to Yahoo
    if not analysis:
        yf = fetch_yf_ohlc("GC=F", 50, 20)
        if yf.get("ok"):
            analysis = hermes_analyzer.analyze(yf.get("m15", []), yf.get("h1", []), yf.get("last_price", current_price))
            data_source = "YAHOO"
            current_price = yf.get("last_price", current_price)
            log(f"Analysis (Yahoo): {analysis['bias']} conf={analysis['confidence']}% DEFCON={analysis['defcon']['level']}")
    
    if not analysis:
        log("Analysis: NO DATA")
    
    # COMMAND
    cmd = read_command()
    cmd_result = None
    if cmd:
        cmd_result = execute_trade(bridge, cmd, account, pos_list)
        if DRY_RUN:
            cmd_result["dry_run"] = True
        log(f"Command: {cmd} -> {cmd_result.get('ok')}")
    
    # BUILD REPORT
    hour = datetime.now(timezone.utc).hour
    sess = "ASIA" if hour < 7 else "LONDON" if hour < 13 else "NY"
    
    lines = [
        "═══════════════════════════════════════════",
        f"HERMES REPORT — {datetime.now(timezone.utc).strftime('%H:%M')} UTC | {sess}",
        f"Source: {data_source or 'NONE'} | Bridge: {'OK' if bridge_ok else 'OFF'}",
        "═══════════════════════════════════════════",
        f"Account: ${balance:.2f} (Equity: ${equity:.2f})",
        f"Price: {current_price:.2f}" if current_price else f"Price: Bid={bid} Ask={ask}",
        f"Positions: {len(pos_list)} open",
    ]
    for p in pos_list:
        ptype = "BUY" if p["type"] == 0 else "SELL"
        lines.append(f"  #{p['ticket']}: {ptype} {p['volume']} lot @ {p['open_price']}$ | P/L: ${p['profit']:.2f}")
    
    lines.append("")
    
    if analysis:
        lines.append("🧠 ANALYSIS:")
        lines.append(f"  Bias: {analysis['bias'].upper()} | Confidence: {analysis['confidence']}% | DEFCON-{analysis['defcon']}")
        lines.append(f"  Action: {analysis['action'].upper()} | Max Lot: {analysis['max_lot']} | Risk: {analysis['risk_pct']}%")
        if analysis['action'] in ['buy', 'sell']:
            lines.append(f"  Suggested SL={analysis['suggested_sl']} TP={analysis['suggested_tp']} ATR={analysis['atr']}")
        lines.append("")
    
    if cmd:
        lines.append(f"📝 COMMAND: {cmd}")
        lines.append(f"Result: {json.dumps(cmd_result)}")
    else:
        if analysis and analysis['action'] in ['buy', 'sell']:
            lines.append("⏳ AWAITING HERMES APPROVAL")
            lines.append(f"  Signal: {analysis['action'].upper()} {analysis['max_lot']} lot")
            lines.append(f"  To execute: echo '/trade {analysis['action']} {analysis['max_lot']}' > {CMD_FILE}")
        else:
            lines.append("NO SIGNAL — Market uncertain / no setup")
    
    lines.append("")
    lines.append("Commands: /trade buy|sell [lot] [sl] [tp] | /close [ticket]")
    
    report = "\n".join(lines)
    os.makedirs(os.path.dirname(REPORT_FILE), exist_ok=True)
    with open(REPORT_FILE, "w") as f:
        f.write(report)
    
    send_telegram(report)
    log("Cycle complete")

if __name__ == "__main__":
    main()
