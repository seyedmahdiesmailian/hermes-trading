#!/bin/bash
# HERMES TRADING CRON — Runs every 15 minutes
# TZ=Asia/Tehran
# 
# FLOW:
#   1. Run hermes_master.py (collect data, check commands, build report)
#   2. If Hermes command exists → execute it
#   3. If no command for 2h+ → apprentice takes over (future)

cd /home/ai/hermes-trading
export PYTHONPATH=/home/ai/hermes-trading

NOW=$(date '+%Y-%m-%d %H:%M:%S')
echo "[$NOW] Cron triggered" >> /home/ai/hermes-trading/logs/cron.log

# Check if Bridge is responsive
BRIDGE_TEST=$(curl -s --max-time 5 http://192.168.10.51:5050/ 2>/dev/null)
BRIDGE_OK=$(echo "$BRIDGE_TEST" | grep -c "Hermes MT5 Bridge" || echo "0")

if [ "$BRIDGE_OK" -eq "0" ]; then
    echo "[$NOW] Bridge DOWN — skipping cycle" >> /home/ai/hermes-trading/logs/cron.log
    # Try to notify
    python3 -c "from scripts.hermes_notifier import send_telegram; send_telegram('⚠️ Bridge DOWN — cycle skipped')" 2>/dev/null
    exit 1
fi

# Run Master cycle
python3 /home/ai/hermes-trading/hermes_master.py >> /home/ai/hermes-trading/logs/master_cron.log 2>&1

RESULT=$?
if [ $RESULT -eq 0 ]; then
    echo "[$NOW] Master cycle OK" >> /home/ai/hermes-trading/logs/cron.log
else
    echo "[$NOW] Master cycle FAILED (exit $RESULT)" >> /home/ai/hermes-trading/logs/cron.log
fi
