#!/usr/bin/env python3
"""
BRIDGE HEALTH MONITOR
═══════════════════════════════════════════════
Runs every 5 minutes via cron.
Checks if MT5 HTTP Bridge is alive.
If dead → restarts it automatically.
"""

import sys
import subprocess
from datetime import datetime, timezone
import os

LOG_FILE = "/home/ai/hermes-trading/logs/bridge_health.log"
BRIDGE_URL = "http://192.168.10.51:5050/"

def log(msg):
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")

def is_bridge_alive():
    try:
        import urllib.request
        req = urllib.request.Request(BRIDGE_URL, method="GET")
        resp = urllib.request.urlopen(req, timeout=5)
        data = resp.read().decode()
        return "Hermes MT5 Bridge" in data
    except Exception as e:
        log(f"Health check failed: {e}")
        return False

def restart_bridge():
    log("RESTARTING Bridge...")
    import winrm
    try:
        session = winrm.Session('192.168.10.51', auth=('Administrator', 'Seyed1107@'), transport='ntlm', server_cert_validation='ignore')
        
        ps = r'''
# Kill old
Get-Process python -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like "*mt5_http*" } | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep 2

# Start new
$p = Start-Process "C:\Program Files\Python311\python.exe" -ArgumentList "C:\Temp\mt5_http_server.py" -WindowStyle Hidden -PassThru
Write-Output "PID=$($p.Id)"
Start-Sleep 5

# Verify
$conn = Get-NetTCPConnection -LocalPort 5050 -ErrorAction SilentlyContinue
if ($conn) { Write-Output "UP" } else { Write-Output "FAIL" }
'''
        r = session.run_ps(ps)
        output = r.std_out.decode('utf-8', errors='replace').strip()
        log(f"Restart result: {output}")
        
        # Double-check
        import time
        time.sleep(2)
        if is_bridge_alive():
            log("Bridge RESTORED successfully")
            return True
        else:
            log("Bridge still DOWN after restart!")
            return False
    except Exception as e:
        log(f"Restart failed: {e}")
        return False

def main():
    log("Health check...")
    if is_bridge_alive():
        log("Bridge OK")
        return 0
    
    log("Bridge DOWN — attempting restart")
    if restart_bridge():
        return 0
    else:
        log("CRITICAL: Could not restart Bridge!")
        # Notify via Telegram
        try:
            sys.path.insert(0, "/home/ai/hermes-trading")
            sys.path.insert(0, "/home/ai/hermes-trading/scripts")
            from scripts.hermes_notifier import send_telegram
            send_telegram("🚨 CRITICAL: Bridge restart failed! Manual intervention needed.")
        except:
            pass
        return 1

if __name__ == "__main__":
    sys.exit(main())
